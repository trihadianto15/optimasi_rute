export interface Location {
  id: string;
  kampung?: string;
  rt?: string;
  rw?: string;
  address: string;
  lat: number;
  lng: number;
  type: 'gudang' | 'delivery';
  originalText?: string;
}
