import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import type { Location } from '../types';

// Fix untuk masalah ikon default Leaflet di Vite/React
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as any)._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
});

const gudangIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

function MapBoundsFitter({ route }: { route: Location[] }) {
  const map = useMap();
  
  useEffect(() => {
    if (route.length > 0) {
      const bounds = L.latLngBounds(route.map(p => [p.lat, p.lng]));
      map.fitBounds(bounds, { padding: [40, 40] });
    }
  }, [route, map]);
  
  return null;
}

export default function RouteMap({ route }: { route: Location[] }) {
  const center: [number, number] = route.length > 0 ? [route[0].lat, route[0].lng] : [-6.200000, 106.816666];
  
  const polylinePositions = route.map(loc => [loc.lat, loc.lng] as [number, number]);

  return (
    <MapContainer 
      center={center} 
      zoom={12} 
      style={{ height: '100%', width: '100%', borderRadius: '0.75rem', zIndex: 10 }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {route.map((loc, idx) => (
        <Marker 
          key={loc.id + idx} 
          position={[loc.lat, loc.lng]}
          icon={loc.type === 'gudang' ? gudangIcon : new L.Icon.Default()}
        >
          <Popup>
            <div className="font-sans">
              <p className="font-semibold">{loc.type === 'gudang' ? '🏢 Gudang' : `📦 Titik Ke-${idx}`}</p>
              <p className="text-sm">{loc.address}</p>
            </div>
          </Popup>
        </Marker>
      ))}

      {polylinePositions.length > 1 && (
        <Polyline positions={polylinePositions} color="#3b82f6" weight={4} opacity={0.8} />
      )}
      
      <MapBoundsFitter route={route} />
    </MapContainer>
  );
}
