import { useState, useCallback, useEffect } from 'react';
import { Upload, FileDown, Route as RouteIcon, MapPin, Calculator, CheckCircle2 } from 'lucide-react';
import RouteMap from './components/RouteMap';
import type { Location } from './types';
import { GUDANG_LOCATION, matchAddressToDatabase, MOCK_DATABASE } from './lib/mockData';
import { solveTSPNearestNeighbor } from './lib/optimization';

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  
  // State dataset statis/tersimpan di "database"
  const [database, setDatabase] = useState<Location[]>([]);

  useEffect(() => {
    const savedDb = localStorage.getItem('optiroute_database');
    if (savedDb) {
      try {
        setDatabase(JSON.parse(savedDb));
      } catch (e) {
        setDatabase(MOCK_DATABASE);
      }
    } else {
      setDatabase(MOCK_DATABASE);
    }
  }, []);

  const [processingStatus, setProcessingStatus] = useState<number>(0); 
  const [extractedAddresses, setExtractedAddresses] = useState<string[]>([]);
  const [route, setRoute] = useState<Location[]>([]);

  // Simulasi Flow OCR & Pencocokan
  const startSimulation = useCallback(() => {
    if (!file) return;
    if (database.length === 0) {
      alert("Harap unggah dataset (Excel/JSON) terlebih dahulu sebelum memproses rute.");
      return;
    }
    
    // Reset state
    setProcessingStatus(1);
    setExtractedAddresses([]);
    setRoute([]);

    // Step 1: Simulasi OCR (2 detik)
    setTimeout(() => {
      setProcessingStatus(2);
      // Dummy text yang merepresentasikan hasil scan kotor: 
      const dummyOcrResult = [
        "Penerima: Budi, Kp. Rimbawan RT 01 RW 04, Senayan.",
        "Kirim ke Kp. Tebet Eco Park, RT 03 RW 01",
        "Kp. Manggarai Station Jakarta, RT 02 RW 02 - Bp. Joko",
        "Drop: Kp. Pasar Senen, Jakarta Pusat RT 05 RW 01"
      ];
      setExtractedAddresses(dummyOcrResult);

      // Step 2: Simulasi Geocoding / Database Matching
      setTimeout(async () => {
        setProcessingStatus(3);
        const matchPromises = dummyOcrResult.map(txt => matchAddressToDatabase(txt, database));
        const matchedLocations = (await Promise.all(matchPromises)).filter(Boolean) as Location[];
        
        // Cek jika tidak ada yang cocok
        if (matchedLocations.length === 0) {
           alert("Tidak ada alamat OCR yang cocok dengan dataset.");
           setProcessingStatus(0);
           return;
        }

        // Step 3: Hitung Rute (Haversine + Nearest Neighbor)
        setTimeout(() => {
          setProcessingStatus(4); // Selesai
          // Jangan lupa tempatkan Gudang pada awal
          const unsortedRoute = [GUDANG_LOCATION, ...matchedLocations];
          const optimized = solveTSPNearestNeighbor(unsortedRoute);
          setRoute(optimized);
        }, 1500);

      }, 2000);

    }, 2000);

  }, [file, database]);

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <RouteIcon className="w-7 h-7 text-blue-600" />
          <h1 className="text-xl font-bold tracking-tight text-slate-800">OptiRoute Logistik</h1>
        </div>
        <div className="text-sm text-slate-500 font-medium">Nearest Neighbor + Haversine</div>
      </header>
      
      <main className="flex-1 flex flex-col lg:flex-row max-w-[1600px] w-full mx-auto overflow-hidden">
        
        {/* Kolom Kiri: Input & Status */}
        <section className="w-full lg:w-1/3 p-6 bg-white border-r border-gray-200 flex flex-col gap-6 overflow-y-auto">
          
          <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100">
            <h2 className="font-semibold text-blue-900 mb-2">Simulasi Skripsi</h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              Sistem akan membaca teks OCR dari foto paket, melakukan pencocokan alamat ke database koordinat (kampung, RT, RW), lalu menghitung rute terpendek.
            </p>
          </div>

          <div 
            className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center transition-colors
              ${file ? 'border-green-400 bg-green-50' : 'border-slate-300 hover:border-blue-400 focus:bg-slate-50'}`}
          >
            {preview ? (
              <img src={preview} className="max-h-32 object-contain mb-4 rounded-md shadow-sm" alt="Preview"/>
            ) : (
              <Upload className="w-10 h-10 text-slate-400 mb-3" />
            )}
            
            <label className="cursor-pointer bg-white px-4 py-2 border border-slate-300 rounded-lg shadow-sm text-sm font-medium hover:bg-slate-50 focus:ring-2 ring-blue-500">
              {file ? 'Pilih Gambar Lain' : 'Unggah Foto Paket (Resi)'}
              <input 
                type="file" className="hidden" accept="image/*" 
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if(f) {
                    setFile(f);
                    setPreview(URL.createObjectURL(f));
                    setProcessingStatus(0);
                    setRoute([]);
                    setExtractedAddresses([]);
                  }
                }}
              />
            </label>
            {file && <span className="mt-3 text-xs text-green-700 font-mono">{file.name}</span>}
          </div>

          <button
            onClick={startSimulation}
            disabled={!file || (processingStatus > 0 && processingStatus < 4)}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-medium py-3 rounded-xl transition-all shadow-md active:scale-95"
          >
            {processingStatus > 0 && processingStatus < 4 ? 'Sedang Memproses...' : 'Mulai Optimasi Rute'}
          </button>

          {/* Proses Status Indikator */}
          <div className="flex flex-col gap-4 mt-4 mb-4">
            
            <StatusRow 
              active={processingStatus >= 1} 
              done={processingStatus > 1}
              icon={<FileDown className="w-5 h-5"/>} 
              title="1. Ekstraksi OCR" 
              desc="Membaca teks dari gambar paket"
            />
            {processingStatus > 1 && (
              <div className="pl-12 pr-4 py-1 text-sm text-slate-700 font-mono bg-slate-50 rounded-md border border-slate-100">
                {extractedAddresses.map((addr, i) => <div key={i} className="truncate">• {addr}</div>)}
              </div>
            )}
            
            <StatusRow 
              active={processingStatus >= 2} 
              done={processingStatus > 2}
              icon={<MapPin className="w-5 h-5"/>} 
              title="2. Pencocokan Koordinat & Geocoding" 
              desc="Mata rantai alamat ke database excel"
            />

            <StatusRow 
              active={processingStatus >= 3} 
              done={processingStatus > 3}
              icon={<Calculator className="w-5 h-5"/>} 
              title="3. Hitung Jarak Haversine & TSP Nearest Neighbor" 
              desc="Optimasi urutan rute terpendek antar titik"
            />

          </div>

          {/* Hasil Rute */}
          {route.length > 0 && (
             <div className="mt-2 bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col">
                <h3 className="font-semibold text-slate-800 border-b border-slate-100 pb-3 mb-4">Urutan Rute (Optimal)</h3>
                <div className="flex flex-col">
                  {route.map((loc, idx) => (
                    <div key={idx} className="flex items-start gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white z-10 shrink-0
                          ${idx === 0 ? 'bg-red-500' : 'bg-blue-600'}`}>
                          {idx}
                        </div>
                        {idx < route.length - 1 && <div className="w-[2px] min-h-[32px] h-full bg-slate-200 my-1" />}
                      </div>
                      <div className="pb-4 pt-1">
                        <div className="text-sm font-bold text-slate-800">{loc.type === 'gudang' ? 'Gudang Utama' : `Tujuan ${idx}`}</div>
                        <div className="text-xs text-slate-500 mt-1 leading-relaxed pr-2">{loc.address}</div>
                      </div>
                    </div>
                  ))}
                </div>
             </div>
          )}
        </section>

        {/* Kolom Kanan: Peta (Map) */}
        <section className="w-full lg:w-2/3 bg-slate-100 p-4 lg:p-6 flex flex-col h-full relative">
          <div className="bg-white absolute top-8 left-10 z-[1000] rounded-lg shadow-lg px-4 py-3 border border-slate-200 pointer-events-none">
            <h3 className="text-sm font-bold text-slate-800">Visualisasi Peta</h3>
            <p className="text-xs text-slate-500">{route.length > 0 ? `Rute Ditemukan (${route.length - 1} Titik)` : 'Menunggu Input...'}</p>
          </div>
          
          <div className="h-[60vh] lg:h-full w-full bg-slate-200 rounded-xl overflow-hidden shadow-inner border border-slate-300">
            {route.length > 0 ? (
               <RouteMap route={route} />
            ) : (
               <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 gap-3">
                 <MapPin className="w-12 h-12 opacity-50" />
                 <p className="font-medium">Unggah resi untuk memulai preview peta</p>
               </div>
            )}
          </div>
        </section>

      </main>
    </div>
  );
}

function StatusRow({ active, done, icon, title, desc }: { active: boolean; done: boolean; icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className={`flex items-start gap-4 transition-all duration-500 ${active ? 'opacity-100' : 'opacity-40 grayscale'}`}>
      <div className={`p-2 rounded-full mt-1 ${done ? 'bg-green-100 text-green-600' : (active ? 'bg-blue-100 text-blue-600 animate-pulse' : 'bg-slate-200 text-slate-500')}`}>
        {done ? <CheckCircle2 className="w-5 h-5"/> : icon}
      </div>
      <div>
        <h3 className={`font-semibold ${done ? 'text-green-700' : (active ? 'text-blue-700' : 'text-slate-600')}`}>{title}</h3>
        <p className="text-sm text-slate-500">{desc}</p>
      </div>
    </div>
  );
}
