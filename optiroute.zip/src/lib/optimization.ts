import type { Location } from '../types';

/**
 * Menghitung jarak lurus (Haversine) antara dua titik koordinat bumi dalam satuan Kilometer
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Jari-jari bumi dalam kilometer
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) *
      Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
      
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Jarak dalam kilometer
  
  return distance;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

/**
 * Menyelesaikan masalah optimasi rute dengan algoritma Nearest Neighbor (TSP).
 * Asumsi: elemen pertama dari `locations` adalah titik Gudang.
 */
export function solveTSPNearestNeighbor(locations: Location[]): Location[] {
  if (locations.length === 0) return [];
  if (locations.length === 1) return locations;

  // Pisahkan gudang (mulai) dengan daftar tujuan yang belum dikunjungi
  const unvisited = [...locations];
  const startNodeIndex = unvisited.findIndex(l => l.type === 'gudang');
  const startNode = startNodeIndex >= 0 ? unvisited.splice(startNodeIndex, 1)[0] : unvisited.shift()!;
  
  const route: Location[] = [startNode];
  let currentNode = startNode;

  // Lakukan pencarian tetangga terdekat (Nearest Neighbor) hingga semua tujuan dikunjungi
  while (unvisited.length > 0) {
    let nearestIndex = 0;
    let minDistance = Infinity;

    for (let i = 0; i < unvisited.length; i++) {
      const dist = calculateHaversineDistance(
        currentNode.lat,
        currentNode.lng,
        unvisited[i].lat,
        unvisited[i].lng
      );
      
      if (dist < minDistance) {
        minDistance = dist;
        nearestIndex = i;
      }
    }

    // Node terdekat ditemukan, pindahkan dari unvisited ke route
    currentNode = unvisited.splice(nearestIndex, 1)[0];
    route.push(currentNode);
  }

  // (Opsional) Kembali ke gudang
  // route.push(startNode);

  return route;
}
