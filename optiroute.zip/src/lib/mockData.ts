import type { Location } from '../types';

export const GUDANG_LOCATION: Location = {
  id: "gudang",
  address: "Gudang Logistik Utama, Jakarta Selatan",
  lat: -6.200000,
  lng: 106.816666,
  type: "gudang"
};

// Simulasi database statis
export const MOCK_DATABASE: Location[] = [
  { id: "del_1", kampung: "Rimbawan", rt: "01", rw: "04", address: "Kp. Rimbawan RT 01/RW 04", lat: -6.214620, lng: 106.802940, type: "delivery" },
  { id: "del_2", kampung: "Tebet Eco Park", rt: "03", rw: "01", address: "Kp. Tebet Eco Park RT 03/RW 01", lat: -6.237240, lng: 106.852440, type: "delivery" },
  { id: "del_3", kampung: "Manggarai Station", rt: "02", rw: "02", address: "Kp. Manggarai Station RT 02/RW 02", lat: -6.209930, lng: 106.849740, type: "delivery" },
  { id: "del_4", kampung: "Pasar Senen", rt: "05", rw: "01", address: "Kp. Pasar Senen RT 05/RW 01", lat: -6.176410, lng: 106.841510, type: "delivery" },
  { id: "del_5", kampung: "Kemang Village", rt: "02", rw: "03", address: "Kp. Kemang Village RT 02/RW 03", lat: -6.262530, lng: 106.810570, type: "delivery" },
];

// Simulasi proses mencocokkan teks hasil ekstraksi OCR
// dengan koordinat di "database" yang kita punya
export async function matchAddressToDatabase(extractedText: string, database: Location[]): Promise<Location | null> {
  const normalizedText = extractedText.toLowerCase();
  
  // Deteksi keyword yang mirip dengan data dataset
  for (const record of database) {
    if (record.kampung) {
      if (normalizedText.includes(record.kampung.toLowerCase())) {
        if (record.rt && record.rw) {
          if (normalizedText.includes(record.rt) || normalizedText.includes(record.rw)) {
            return { ...record, originalText: extractedText };
          }
        }
        return { ...record, originalText: extractedText };
      }
    }

    if (!record.address) continue;
    const keywords = record.address.split(' ').filter(w => w.length > 3);
    for (const kw of keywords) {
      if (normalizedText.includes(kw.toLowerCase())) {
        return { ...record, originalText: extractedText };
      }
    }
  }
  
  return null; 
}
